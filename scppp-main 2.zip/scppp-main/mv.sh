cd /usr/bin/
cd ~/
history -c