#!/bin/bash

clear
echo -e "================================================="| lolcat
echo -e "#         Premium Auto Script By NISHAT VPN     #"| lolcat
echo -e "#-----------------------------------------------#"| lolcat
echo -e "# For Debian 9 & Debian 10 64 bit               #"| lolcat
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"| lolcat
echo -e "# For VPS with KVM and VMWare virtualization    #"| lolcat
echo -e "# Build Up By NISHAT VPN                        #"| lolcat
echo -e "#-----------------------------------------------#"| lolcat
